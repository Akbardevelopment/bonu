$("bot").click(function(){
    $(".container1").show();
  });